# YOLOv11 Prohibited Item Detection - Part B
Airport security X-ray image analysis using YOLOv11n trained on OPIXray.

# Option 1 - Run it Locally (with GPU)
Requirements:
|
|- Python 3.11
|- NVIDIA GPU with CUDA 12.1

# Setup
bashpip install -r requirements.txt
python app.py
Open http://localhost:5000 in your browser.

---

# Option 2 - Run it with Docker
Build the image -> bashdocker build -t xray-detector .
Run the container (CPU) -> bashdocker run -p 5000:5000 xray-detector
Run with GPU support -> bashdocker run --gpus all -p 5000:5000 xray-detector
Open http://localhost:5000 in your browser.

---

# API Endpoints
| Method | Endpoint | Description                  |
|--------|----------|------------------------------|
| GET    |  /       | Web UI                       |
| GET    |  /health | Service status + model info  |
| GET    |  /info   | Full metrics and class names |
| POST   |  /detect | Run detection on an image    |


# POST /detect  Example
```bash
curl -X POST http://localhost:5000/detect \
  -F "image=@demo_images/042904.jpg"
```

**Response:**
```json
{
  "status": "ok",
  "inference_ms": 12.4,
  "count": 1,
  "threat_detected": true,
  "detections": [
    {
      "class": "Folding_Knife",
      "class_id": 0,
      "confidence": 0.9231,
      "bbox": { "x1": 120, "y1": 85, "x2": 310, "y2": 190 }
    }
  ],
  "image": "<base64 annotated image>"
}
```

# Python integration example
```python
import requests

response = requests.post(
    "http://localhost:5000/detect",
    files={"image": open("demo_images/042904.jpg", "rb")}
)
print(response.json()["detections"])
```

---

# Performance of the model
| Classes          | Precision |   Recall  |   mAP50   |  mAP50-95 | 
|------------------|-----------|-----------|-----------|-----------| 
| Folding Knife    |   0.887   |   0.923   |   0.932   |   0.431   | 
| Straight Knife   |   0.841   |   0.591   |   0.737   |   0.309   |
| Scissor          |   0.977   |   0.970   |   0.976   |   0.510   |
| Utility Knife    |   0.797   |   0.825   |   0.844   |   0.422   |
| Multi-tool Knife |   0.903   |   0.885   |   0.942   |   0.427   |
| **Overall**      | **0.881** | **0.839** | **0.886** | **0.420** |

---

## Environment
- Python 3.11.9
- PyTorch 2.5.1+cu121
- Ultralytics 8.4.46
- CUDA 12.1
- NVIDIA RTX 4060 Laptop GPU (8GB VRAM)
