from flask import Flask, request, jsonify, render_template
import base64
import cv2
import numpy
from ultralytics import YOLO
import os
import time

app= Flask(__name__)

# Loading the model once at startup
Ws_PATH= "runs/yolo11_opixray/weights/best.pt"
model= YOLO(Ws_PATH)

Classe_Names= ['Folding_Knife', 'Straight_Knife', 'Scissor', 'Utility_Knife', 'Multi-tool_Knife']
Classe_Colors= {
    'Folding_Knife':    (255, 80,  80), 
    'Straight_Knife':   (80,  200, 255), 
    'Scissor':          (80,  255, 120), 
    'Utility_Knife':    (255, 200, 80), 
    'Multi-tool_Knife': (200, 80,  255), 
}

# Web Interface 
@app.route('/')
def index():
    return render_template('index.html')

# Health check, verifying the module is alive
@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'ok',
        'model': 'YOLOv11n',
        'classes': Classe_Names,
        'mAP50': 0.886
    })

# Model info
@app.route('/info', methods=['GET'])
def info():
    return jsonify({
        'model': 'YOLOv11n (ultralytics)',
        'dataset': 'OPIXray',
        'classes': Classe_Names,
        'num_classes': len(Classe_Name),
        'input_size': 640,
        'metrics': {
            'mAP50': 0.886,
            'mAP50_95': 0.420,
            'precision': 0.881,
            'recall': 0.839
        },
        'per_class_mAP50': {
            'Folding_Knife': 0.932,
            'Straight_Knife': 0.737,
            'Scissor': 0.976,
            'Utility_Knife': 0.844,
            'Multi-tool_Knife': 0.942
        }
    })

# Detection endpoint - accepting image, returning detections as JSON 
@app.route('/detect', methods=['POST'])
def detect():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided. Send a multipart/form-data request with key "image".'}), 400

    file= request.files['image']
    img_b= file.read()
    np_arr= numpy.frombuffer(img_b, numpy.uint8)
    img= cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    if img is None:
        return jsonify({'error': 'Could not decode image. Ensure it is a valid JPG or PNG.'}), 400

    start_time= time.time()
    results= model(img, verbose=False)[0]
    elapsed_ms= round((time.time() - start_time) * 1000, 1)

    detections= []
    for box in results.boxes:
        cls_id= int(box.cls[0])
        confidence= float(box.conf[0])
        cls_name= Classe_Names[cls_id]
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        color= Classe_Colors.get(cls_name, (255, 255, 255))

        # Drawing the bounding box + label on image
        cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
        lbl = f"{cls_name} {confidence:.2f}"
        (tw, th), _ = cv2.getTextSize(lbl, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(img, (x1, y1 - th - 8), (x1 + tw + 4, y1), color, -1)
        cv2.putText(img, lbl, (x1 + 2, y1 - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 1)

        detections.append({
            'class':      cls_name,
            'class_id':   cls_id,
            'confidence': round(confidence, 4),
            'bbox': {
                'x1': x1, 'y1': y1,
                'x2': x2, 'y2': y2
            }
        })

    # Encode annotated image to base64 for web UI
    _, buffer= cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, 92])
    img_b64= base64.b64encode(buffer).decode('utf-8')

    return jsonify({
        'status':          'ok',
        'inference_ms':    elapsed_ms,
        'count':           len(detections),
        'threat_detected': len(detections) > 0,
        'detections':      detections,
        'image':           img_b64
    })

# Error handlers 
@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({'error': 'Internal server error', 'detail': str(e)}), 500

if __name__ == '__main__':
    print("Starting X-Ray Security Detection API...")
    print("Web UI:    http://localhost:5000")
    print("Health:    http://localhost:5000/health")
    print("Info:      http://localhost:5000/info")
    print("Detect:    POST http://localhost:5000/detect")
    app.run(debug=False, port=5000)
